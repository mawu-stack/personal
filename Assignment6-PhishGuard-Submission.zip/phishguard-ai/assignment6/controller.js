(()=>{
 'use strict';
 const $=id=>document.getElementById(id);
 const metrics=()=>{try{return JSON.parse($('a6-results-json').textContent);}catch(_){return null;}};
 function encodeHTMLText(value){return value.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
 function renderTo(value,safe,encoded){
   if(typeof value!=='string'||!value.trim()||value.length>2000||/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value))return false;
   safe.textContent=value;encoded.textContent=encodeHTMLText(value);return true;
 }
 function render(){const ok=renderTo($('a6-input').value,$('a6-safe-output'),$('a6-encoded-output'));$('a6-input-status').textContent=ok?'Rendered as inert text. No HTML elements were created.':'Enter 1–2,000 characters without unsupported control characters.';if(!ok){$('a6-safe-output').replaceChildren();$('a6-encoded-output').replaceChildren();}}
 function tests(){
   const report=[],safe=document.createElement('pre'),encoded=document.createElement('pre');
   const check=(ok,name)=>{report.push((ok?'PASS ':'FAIL ')+name);};
   for(const sample of ['<img src=x onerror="alert(1)">','<svg onload="alert(1)">','<script>alert(1)<'+ '/script>','<a href="javascript:alert(1)">link</a>','A & B "quoted" \'single\'','Unicode: café 😀\nsecond line']){
     check(renderTo(sample,safe,encoded)&&safe.textContent===sample&&safe.children.length===0&&encoded.textContent===encodeHTMLText(sample),'Text preserved without parsed elements: '+sample.slice(0,45));
   }
   check(!renderTo('x'.repeat(2001),safe,encoded),'Oversized input rejected by application validation');
   check(!renderTo('   ',safe,encoded),'Empty/whitespace input rejected');
   check(!renderTo('x\u0000y',safe,encoded),'Unsupported control character rejected');
   check(encodeHTMLText('<>&"\'')==='&lt;&gt;&amp;&quot;&#39;','HTML text encoding covers special characters');
   const result={passed:report.filter(x=>x.startsWith('PASS')).length,failed:report.filter(x=>x.startsWith('FAIL')).length};
   $('a6-test-output').textContent=report.join('\n')+'\n'+result.passed+' passed; '+result.failed+' failed. Measured in this browser.';
   window.SecurityState?.logEvent('ASSIGNMENT6','XSS text-control tests: '+result.passed+' passed, '+result.failed+' failed.','info');return result;
 }
 const names={lexical_logistic_regression:'Lexical Logistic Regression',lexical_random_forest:'Lexical Random Forest',character_linear:'Character-only linear model',hybrid:'Selected hybrid'};
 const pct=n=>(100*n).toFixed(2)+'%';
 function download(name,content,type){const blob=new Blob([content],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 function renderResults(){
   const r=metrics();
   if(!r?.test){$('a6-results-status').textContent='Awaiting measured results. Run assignment6/experiment.py and export the tab; no sample scores are shown.';$('a6-download-results').disabled=true;return;}
   $('a6-data-summary').textContent=r.dataset.raw_rows.toLocaleString()+' source rows; '+r.dataset.retained.toLocaleString()+' retained binary rows ('+r.dataset.classes.phishing.toLocaleString()+' phishing / '+r.dataset.classes.benign.toLocaleString()+' benign). Source contains raw URLs, not page content.';
   $('a6-split-summary').textContent=r.split.inner_fit.toLocaleString()+' inner fit / '+r.split.inner_validation.toLocaleString()+' validation, inside '+r.split.outer_train.toLocaleString()+' outer training rows. All methods use the same '+r.split.historical_test.toLocaleString()+' historical test rows. Domain overlap: '+r.split.domain_overlap+'.';
   $('a6-compute-summary').textContent='Measured experiment duration: '+r.timing.total_seconds.toFixed(1)+' s on '+r.runtime.machine+' / Python '+r.runtime.python+' / scikit-learn '+r.runtime.sklearn+'. CPU only. Character model full fit: '+r.timing.full_character_fit_seconds.toFixed(1)+' s. Existing full-training Random Forest artifact was reused after checksum and prediction verification.';
   $('a6-results-status').textContent='Actual results generated '+r.date+'. Phishing is the positive class; threshold 0.5. Historical test reuse makes this an exploratory extension.';
   for(const [key,value] of Object.entries(r.test)){
     const row=document.createElement('tr');for(const content of [names[key],...['accuracy','precision','recall','f1','fpr','fnr','average_precision','roc_auc'].map(k=>pct(value[k]))]){const td=document.createElement('td');td.textContent=content;row.append(td);}$('a6-metric-rows').append(row);
     const bar=document.createElement('div');bar.className='a6-bar';const label=document.createElement('div');label.className='a6-bar-label';const name=document.createElement('span'),number=document.createElement('strong');name.textContent=names[key];number.textContent=pct(value.f1);label.append(name,number);const progress=document.createElement('progress');progress.max=1;progress.value=value.f1;progress.setAttribute('aria-label',names[key]+' phishing F1');bar.append(label,progress);$('a6-f1-bars').append(bar);
     const paragraph=document.createElement('p');paragraph.textContent=names[key]+': '+JSON.stringify(value.confusion_matrix)+' (rows actual benign/phishing; columns predicted benign/phishing).';$('a6-confusion').append(paragraph);
   }
   const base=r.test.lexical_random_forest,hybrid=r.test.hybrid,diff=(hybrid.f1-base.f1)*100,rate=(hybrid.fpr-base.fpr)*100;
   $('a6-interpretation').textContent='Relative to the lexical Random Forest, hybrid F1 '+(diff>=0?'increased':'decreased')+' by '+Math.abs(diff).toFixed(2)+' percentage points. False-positive rate '+(rate>=0?'increased':'decreased')+' by '+Math.abs(rate).toFixed(2)+' points. Hybrid precision '+pct(hybrid.precision)+'; recall '+pct(hybrid.recall)+'. Neither metric alone proves practical deployment readiness.';
   $('a6-uncertainty').textContent='Paired domain-bootstrap 95% percentile interval for F1 difference: '+r.bootstrap.f1_difference_95_percentile.map(v=>(v*100).toFixed(2)).join(' to ')+' percentage points. '+r.bootstrap.note;
   $('a6-validation').textContent='Validation selected character weight '+r.validation.selected_character_weight+'. Candidate validation F1: '+r.validation.candidate_hybrids.map(c=>c.character_weight+' → '+pct(c.f1)).join('; ')+'. Lexical-only validation F1 '+pct(r.validation.lexical_random_forest.f1)+'; character-only '+pct(r.validation.character_linear.f1)+'.';
 }
 function boot(){
   $('a6-render').addEventListener('click',render);
   $('a6-example').addEventListener('click',()=>{$('a6-input').value='<img src=x onerror="alert(\'XSS\')">';render();});
   $('a6-clear').addEventListener('click',()=>{$('a6-input').value='';$('a6-safe-output').replaceChildren();$('a6-encoded-output').replaceChildren();$('a6-input-status').textContent='Cleared. Input is not saved.';});
   $('a6-run-tests').addEventListener('click',tests);
   $('a6-download-results').addEventListener('click',()=>{const r=metrics();if(r?.test)download('assignment6-results.json',JSON.stringify(r,null,2),'application/json');});
   $('a6-download-report').addEventListener('click',()=>{try{const value=JSON.parse($('a6-report-json').textContent);if(!value){$('a6-results-status').textContent='Write-up missing. Run make_deliverables.py and export the tab.';return;}download('assignment6-submission.md',value,'text/markdown;charset=utf-8');}catch(_){$('a6-results-status').textContent='Write-up could not be loaded.';}});
   window.Assignment6={renderTo,encodeHTMLText,runTests:tests};renderResults();
   window.keanCommandRegistry?.register('Open Assignment 6',['open assignment 6','open assignment six','open xss lab','go to assignment 6'],say=>{window.switchTab('tab-9');say('Opened Assignment 6: XSS security and research.');},'Navigate',$('tab-btn-9'));
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
