# Assignment 6 submission bundle

Start with `phishguard-ai/assignment6/submission.md`. It covers the research problem, method selection, baseline, specific proposed improvement, fair experiment, actual findings, XSS controls and limitations. Review the draft before submitting. Nothing has been uploaded to Canvas.

## Open the demonstration

`index-cmdk.html` is the single-file workbench. Open it, use the public throwaway credentials shown on its login screen, then choose **09 Assignment 6 - XSS & Research**. The report/results are embedded and do not require a Python API or AI key. To run the browser fixture locally:

```powershell
node assignment6-preview.cjs
```

Open http://127.0.0.1:3511/test and click Run checks. The desktop preview is http://127.0.0.1:3511/index-cmdk.html#tab-9.

## Reproduce the experiment

This bundle excludes large datasets, environments and model binaries. Use Python 3.12 and the pinned requirements. From `phishguard-ai`:

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r backend/requirements.txt
cd backend
..\.venv\Scripts\python.exe download_data.py
..\.venv\Scripts\python.exe train.py
cd ..
.venv\Scripts\python.exe assignment6/experiment.py
.venv\Scripts\python.exe assignment6/verify_experiment.py
```

Execute `assignment6/research.ipynb` using that environment from its directory. It verifies saved predictions and generates the included charts. The saved notebook already contains executed outputs. The full original repository also contains a standalone Flutter/FastAPI scanner; this submission bundle focuses on the workbench and Assignment 6 research, so the parent README's full-application commands need that repository.

The historical test set was inspected in earlier work. The new model weight uses an inner validation split, but the extension remains exploratory. Neither the measured detection gains nor XSS lab controls establish production protection.

## Source preservation checks

Use Node.js 24+ and install the locked parser dependency:

```powershell
npm ci --prefix .html-audit
node verify-assignment6.mjs
```

The verifier compares the pre-change backup and declared edits, confirms protected tabs/controllers are preserved, and checks HTML, JavaScript, CSS and embedded results. `build-assignment6.mjs` updates the existing file's Assignment 6 markers; do not run old reconstruction scripts from unrelated project versions.

Actual test evidence is in `phishguard-ai/assignment6/verification.md` and `browser-results.txt`. No physical microphone or paid AI provider test is claimed.
